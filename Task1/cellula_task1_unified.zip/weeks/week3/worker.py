
# Minimal, dependency-light reimplementation of your Week 3 notebook flow.
# Replace internals if you have better checkpoints.

from functools import lru_cache
try:
    import faiss
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from sentence_transformers import SentenceTransformer
    import numpy as np
except Exception as e:
    faiss = None
    AutoTokenizer = AutoModelForCausalLM = SentenceTransformer = None
    np = None

MODEL_ID = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
EMB_ID   = "sentence-transformers/all-MiniLM-L6-v2"

@lru_cache(maxsize=1)
def ensure_models():
    if AutoTokenizer is None:
        raise RuntimeError("Please install transformers, sentence-transformers, faiss-cpu, numpy")
    return True

@lru_cache(maxsize=1)
def _emb():
    return SentenceTransformer(EMB_ID)

@lru_cache(maxsize=1)
def _tok():
    return AutoTokenizer.from_pretrained(MODEL_ID)

@lru_cache(maxsize=1)
def _lm():
    return AutoModelForCausalLM.from_pretrained(MODEL_ID)

@lru_cache(maxsize=1)
def _toy_corpus():
    # You can replace by your real prompts corpus
    docs = [
        "Use Python slicing to reverse a list: a[::-1]",
        "Use two pointers to reverse a list in-place by swapping ends until they meet.",
        "In C++, use std::reverse(v.begin(), v.end()).",
        "In JavaScript, use arr.reverse() to reverse in place.",
    ]
    return docs

@lru_cache(maxsize=1)
def _faiss_index():
    docs = _toy_corpus()
    em = _emb()
    vecs = em.encode(docs, convert_to_numpy=True, normalize_embeddings=True)
    d = vecs.shape[1]
    index = faiss.IndexFlatIP(d)
    index.add(vecs)
    return index

def retrieve_prompt(query, k=1):
    docs = _toy_corpus()
    em = _emb()
    index = _faiss_index()
    v = em.encode([query], convert_to_numpy=True, normalize_embeddings=True)
    D, I = index.search(v, k)
    picked = [docs[i] for i in I[0]]
    return "\n".join(f"- {p}" for p in picked)

def build_prompt(user_query, retrieved):
    return f"""You are a careful assistant. User task: {user_query}
Helpful reminders:
{retrieved}

Write only code in Python enclosed in a single block.
"""

def _extract_first_code_block(text):
    if "```" in text:
        # naive extraction
        part = text.split("```", 2)
        if len(part) >= 2:
            body = part[1]
            if body.strip().startswith("python"):
                body = body.split("\n",1)[1]
            return body.strip()
    return text.strip()

def generate_code(prompt):
    tok = _tok()
    lm = _lm()
    inputs = tok(prompt, return_tensors="pt")
    out = lm.generate(
        **inputs,
        max_new_tokens=200,
        do_sample=False,
        eos_token_id=tok.eos_token_id,
        pad_token_id=tok.eos_token_id,
    )
    text = tok.decode(out[0], skip_special_tokens=True)
    return _extract_first_code_block(text)
