
import streamlit as st
from .worker import ensure_models, retrieve_prompt, build_prompt, generate_code

def render():
    st.subheader("Week 3 — Retrieval-Augmented Code Generator")
    st.caption("FAISS + sentence-transformers retrieval to improve a small code LLM's responses.")
    query = st.text_area("Describe your coding task:", height=140, placeholder="e.g., write a Python function to reverse a list")
    k = st.slider("Top-K retrieved prompts", 1, 5, 1)
    if st.button("Generate Code"):
        with st.spinner("Loading models / indexes..."):
            ensure_models()
        with st.spinner("Retrieving and generating..."):
            prompt = retrieve_prompt(query, k=k)
            final = build_prompt(query, prompt)
            code = generate_code(final)
        st.markdown("**Generated Code**")
        st.code(code or "# [no code produced]", language="python")
