
import numpy as np
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

def _build():
    emb = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    texts = [
        "Chroma stores embeddings on disk in a folder.",
        "This is a tiny RAG demo using a local embedding model.",
    ]
    metas = [{"src": "note1"}, {"src": "note2"}]
    db = Chroma.from_texts(texts=texts, embedding=emb, metadatas=metas, collection_name="mini_eval")
    return db.as_retriever(search_kwargs={"k": 5})

def _dcg(scores):
    return sum(rel/np.log2(i+2) for i, rel in enumerate(scores))

def _ndcg_at_k(scores, k):
    gains = scores[:k]
    ideal = sorted(scores, reverse=True)[:k]
    return (_dcg(gains) / max(_dcg(ideal), 1e-9))

def _mrr(ranked_ids, rel_set):
    for idx, i in enumerate(ranked_ids, 1):
        if i in rel_set:
            return 1.0/idx
    return 0.0

def run_metrics_demo(K=3) -> str:
    retriever = _build()
    query = "embeddings saved where?"
    docs = retriever.get_relevant_documents(query)
    ranked_ids = list(range(len(docs)))
    rel = {0}  # assume first is relevant in toy example
    binary = [1 if i in rel else 0 for i in ranked_ids]

    hits_at_k = sum(1 for i in ranked_ids[:K] if i in rel)
    prec = hits_at_k / max(1, K)
    rec = hits_at_k / max(1, len(rel))
    mrr = _mrr(ranked_ids, rel)
    ndcg = _ndcg_at_k(binary, K)
    return f"Precision@{K}={prec:.3f}  Recall@{K}={rec:.3f}  MRR={mrr:.3f}  nDCG@{K}={ndcg:.3f}"
