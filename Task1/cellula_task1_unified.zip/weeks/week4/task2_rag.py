
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings

PERSIST_DIR = "chroma_db_cellula_w4"

def ensure_db():
    emb = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    texts = [
        "Chroma stores embeddings on disk in a folder.",
        "This is a tiny RAG demo using a local embedding model.",
    ]
    metas = [{"src": "note1"}, {"src": "note2"}]
    db = Chroma.from_texts(texts=texts, embedding=emb, metadatas=metas,
                           collection_name="mini", persist_directory=PERSIST_DIR)
    db.persist()

def query_demo(q: str):
    emb = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    db = Chroma(collection_name="mini", embedding_function=emb, persist_directory=PERSIST_DIR)
    docs = db.similarity_search(q, k=1)
    return docs[0].page_content if docs else "[no result]"
