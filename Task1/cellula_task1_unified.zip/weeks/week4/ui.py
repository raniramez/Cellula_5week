
import streamlit as st
from .task1_memory import run_memory_demo
from .task2_rag import ensure_db, query_demo
from .task3_metrics import run_metrics_demo
from .task4_deepeval import run_deepeval_demo

def render():
    st.subheader("Week 4 — LangChain & RAG Utilities")
    sub = st.radio("Choose subtask", ["Task 1: Memory Chat", "Task 2: Mini RAG", "Task 3: Retrieval Metrics", "Task 4: DeepEval"], horizontal=True)
    if sub == "Task 1: Memory Chat":
        user1 = st.text_input("First user message", "List 3 lake-view travel destinations.")
        user2 = st.text_input("Follow-up message", "Make a weekend plan for one of them.")
        if st.button("Run Memory Chat"):
            st.write(run_memory_demo(user1, user2))
    elif sub == "Task 2: Mini RAG":
        q = st.text_input("Query", "Where are the embeddings saved?")
        if st.button("Build DB & Search"):
            ensure_db()
            res = query_demo(q)
            st.json({"result": res})
    elif sub == "Task 3: Retrieval Metrics":
        K = st.slider("K", 1, 5, 3)
        if st.button("Run Metrics"):
            st.text(run_metrics_demo(K))
    else:
        if st.button("Run DeepEval demo (needs OPENAI_API_KEY)"):
            st.text(run_deepeval_demo())
