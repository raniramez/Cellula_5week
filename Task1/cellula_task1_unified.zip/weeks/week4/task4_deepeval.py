
import os
from deepeval import evaluate
from deepeval.metrics import FaithfulnessMetric, AnswerRelevancyMetric
from deepeval.test_case import LLMTestCase

def _answer(query: str) -> str:
    if "async" in query.lower():
        return "FastAPI supports async APIs using ASGI."
    if "flask" in query.lower():
        return "Flask is a micro web framework for Python."
    return "I'm not sure."

def _to_text_list(ctx):
    return [f"- {c}" for c in ctx]

def run_deepeval_demo() -> str:
    if not os.getenv("OPENAI_API_KEY"):
        return "OPENAI_API_KEY not set."
    queries = [
        "Does FastAPI support async?",
        "What is Flask used for?"
    ]
    contexts = [
        ["ASGI is the async server interface.", "FastAPI builds on Starlette."],
        ["Flask is a micro framework.", "Werkzeug and Jinja2 are core deps."]
    ]
    tcs = [
        LLMTestCase(
            input=q,
            retrieval_context=_to_text_list(ctx),
            actual_output=_answer(q),
        ) for q, ctx in zip(queries, contexts)
    ]
    metrics = [FaithfulnessMetric(), AnswerRelevancyMetric()]
    rep = evaluate(test_cases=tcs, metrics=metrics)
    return str(rep)
