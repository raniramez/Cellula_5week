
from langchain_huggingface import HuggingFacePipeline
from langchain.memory import ConversationBufferWindowMemory
from langchain.chains import LLMChain
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

def run_memory_demo(msg1: str, msg2: str) -> str:
    llm = HuggingFacePipeline.from_model_id(
        model_id="microsoft/Phi-3-mini-4k-instruct",
        task="text-generation",
        model_kwargs={"torch_dtype": "auto"},
        pipeline_kwargs={
            "top_k": 50, "temperature": 0.1, "return_full_text": False,
            "max_new_tokens": 256,
        },
    )
    mem = ConversationBufferWindowMemory(k=5, memory_key="history", return_messages=True)
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful travel assistant who remembers previous context."),
        MessagesPlaceholder("history"),
        ("human", "{user_input}")
    ])
    chain = LLMChain(llm=llm, prompt=prompt, memory=mem)
    r1 = chain.invoke({"user_input": msg1})["text"].strip()
    r2 = chain.invoke({"user_input": msg2})["text"].strip()
    return r1 + "\n\n---\n\n" + r2
