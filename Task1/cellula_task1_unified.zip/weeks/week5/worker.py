
from typing import TypedDict
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from langchain_openai import ChatOpenAI

class AgentState(TypedDict):
    message: str
    answer: str

def compliment_node(state: AgentState) -> AgentState:
    state["answer"] = f"You are a nice person. {state['message']}"
    return state

def build_graph_app():
    builder = StateGraph(AgentState)
    builder.add_node("compliment", compliment_node)
    builder.set_entry_point("compliment")
    builder.add_edge("compliment", END)
    memory = MemorySaver()
    return builder.compile(checkpointer=memory)
