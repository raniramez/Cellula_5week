
import streamlit as st
from .worker import build_graph_app

def render():
    st.subheader("Week 5 — LangGraph Code Assistant (CLI turned UI)")
    st.caption("Minimal port of your LangGraph assistant to Streamlit. No Mermaid image; interaction below.")
    app = build_graph_app()
    user = st.text_input("Message", "write a function to reverse a list")
    if st.button("Ask Assistant"):
        state = app.invoke({"message": user}, config={"configurable": {"thread_id": "st"}})
        st.markdown("**Assistant**")
        st.write(state.get("answer", "[no answer]"))
