
import os
import streamlit as st

st.set_page_config(page_title="Cellula — Unified Weeks 3–5", layout="wide")
st.title("Cellula Internship — Task 1: All System Deployment (Weeks 3, 4 & 5)")

with st.sidebar:
    st.header("Config")
    openai_key = st.text_input("OPENAI_API_KEY", type="password")
    if openai_key:
        os.environ["OPENAI_API_KEY"] = openai_key

section = st.selectbox("Choose Module", ["Week 3", "Week 4", "Week 5"])

if section == "Week 3":
    import weeks.week3.ui as w3
    w3.render()
elif section == "Week 4":
    import weeks.week4.ui as w4
    w4.render()
else:
    import weeks.week5.ui as w5
    w5.render()
