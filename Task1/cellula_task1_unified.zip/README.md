# Cellula — Unified Weeks 3–5 (Task 1)

This Streamlit app merges Week 3, Week 4, and Week 5 tasks into **one deployable system**.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

- If you plan to run Week 4 Task 4 or Week 5 with OpenAI, set your key in the sidebar field or export `OPENAI_API_KEY`.

## Structure
- `weeks/week3`: Retrieval-augmented code generator (FAISS + sentence-transformers + TinyLlama)
- `weeks/week4`: 
  - Task 1: Memory chat (Phi-3-mini via HuggingFacePipeline)
  - Task 2: Mini RAG with Chroma
  - Task 3: Retrieval metrics (Precision@K, Recall@K, MRR, nDCG)
  - Task 4: DeepEval skeleton
- `weeks/week5`: LangGraph code assistant (simplified UI)

Replace internals with your exact scripts if needed; the interfaces are already wired to the UI.
